[
    { 
        "href": "/", 
        "title": "Home", 
        "content": "Home content."
    },
    { 
        "href": "/about", 
        "title": "About", 
        "content": "About content."
    },
    { 
        "href": "/portfolio", 
        "title": "Portfolio", 
        "content": "Portfolio content."
    },
    { 
        "href": "/contact", 
        "title": "Contact", 
        "content": "Contact content."
    }
]